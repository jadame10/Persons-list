export const PRODUCTS = "products";
export const SUPPLIERS = "suppliers";