export const STORE = "STORE";
export const UPDATE = "UPDATE";
export const DELETE = "DELETE";