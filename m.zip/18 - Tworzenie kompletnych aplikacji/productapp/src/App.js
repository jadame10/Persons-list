import React, { Component } from "react";
import ProductsAndSuppliers from "./ProductsAndSuppliers";

export default class App extends Component {
  
  render() {
    return <ProductsAndSuppliers />
  }
}